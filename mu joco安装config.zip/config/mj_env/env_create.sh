#!/bin/bash
export C_INCLUDE_PATH="/data2/wanpenzhang/.anaconda3/envs/"$1"/include:$C_INCLUDE_PATH"
conda env create -n $1 -f $2
